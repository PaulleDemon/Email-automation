

const EMAIL_CAMPAIGN = {
    upload_size: 300 // 300 kb
}

const TEMPLATE = {
    attachment_size: 10 // 10mb
}